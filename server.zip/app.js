// 在公司里，一般这个静态资源托管不用我们前端去做，一般是后台Java做的，而是跨域也不用我们去做，一般是后台
// java做nginx反向代理
// 我们找一个express中间件， 这个中间件专门用来解决跨域问题的（反向代理）
const express = require('express')
var { createProxyMiddleware } = require('http-proxy-middleware');
const app = express()
//历史模式history需要后台配置，如果是express多了这二行
var history = require('connect-history-api-fallback');
app.use(history());
// 反向代理
app.use('/prod-api', createProxyMiddleware({
    target: 'http://ihrm-java.itheima.net/api',
    changeOrigin: true,
    pathRewrite: {
        '^/prod-api': ''
    }
}))
app.use(express.static('./dist'))//静态资源托管 托管dist目录
app.listen(80, () => {
    console.log('服务器创建成功');
})

