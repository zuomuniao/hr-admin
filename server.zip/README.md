npm run build 项目代码写完了之后，我们正常只要打包成一个 dist 目录，把 dist 目录发给 java 后台就完了

=====================

如果是项目不急，公司也需要做 cdn（cdn 是要收费的）,那就需要优化 0. 分析项目打包之后哪些第三方库导致这个包 dist 比较大 + npm run preview -- --report + 得到一个图 哪些图面积大，说明这个包比较大 我们就需要对这些包进行排除，不用本地，用 cdn 上

1. 打开 vue.config.js 做二件事件
   - externals
   - cdn 暴露给 public/index.html
   - 只对线上 production 模式才做配置

```js
externals = {
  // key就是yarn add 包名
  // key(包名) / value(这个值 是 需要在CDN中获取js, 相当于 获取的js中 的该包的全局的对象的名字)
  vue: 'Vue', // 后面的名字不能随便起 应该是 js中的全局对象名
  'element-ui': 'ELEMENT', // 都是js中全局定义的
  xlsx: 'XLSX', // 都是js中全局定义的
}
```

2. 打开 public/index.html

```html
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"
    />
    <link rel="icon" href="<%= BASE_URL %>favicon.ico" />
    <title><%= webpackConfig.name %></title>
    <!-- 引入样式 -->

    <% for(var css of htmlWebpackPlugin.options.cdn.css) { %>
    <link rel="stylesheet" href="<%=css%>" />
    <% } %>

    <!-- 引入JS -->
    <% for(var js of htmlWebpackPlugin.options.cdn.js) { %>
    <script src="<%=js%>"></script>
    <% } %>
  </head>
  <body>
    <noscript>
      <strong
        >We're sorry but <%= webpackConfig.name %> doesn't work properly without
        JavaScript enabled. Please enable it to continue.</strong
      >
    </noscript>
    <div id="app"></div>
    <!-- built files will be auto injected -->
  </body>
</html>
```

跨域

1. jsonp（这个废弃掉了，只要理解原理，为了面试用的）
2. cors（如果公司用的是这个，前端什么也不用做
3. 反向代理
   - 在开发的时候，需要配置 vue.config.js 中 proxy
   - 在线上的时候，直接给后台 java 说你配一下 nginx 反向代理
